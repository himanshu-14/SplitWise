package billsharing.repository;

import java.util.Map;

import billsharing.model.UserGroup;

public class GroupRepository {

	public static Map<String,UserGroup> groupMap;

}
