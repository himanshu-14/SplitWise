package billsharing.repository;

import java.util.Map;

import billsharing.model.User;

public class UserRepository {
	public static Map<String,User> userMap;

}
