package extras;

import java.util.HashMap;
import java.util.Map;
import billsharing.repository.GroupRepository;

public class SplitService {
	Map<String,Double> generateSplit(String userInput,String groupName){
		HashMap<String,Double> split=new HashMap<>();
		if(userInput.equalsIgnoreCase("EQUAL")) {
//			GroupRepository.
		}
		else if(userInput.equalsIgnoreCase("RATIOS"))
			
		return split;
	}

}
